package com.batonsystems.banksimulator.exception;

public class BranchException extends Exception{

    public BranchException(String exceptionMsg){
        super(exceptionMsg);
    }

}
