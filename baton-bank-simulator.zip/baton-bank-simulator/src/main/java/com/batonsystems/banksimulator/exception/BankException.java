package com.batonsystems.banksimulator.exception;

public class BankException extends Exception{

    public BankException(String exceptionMsg)
    {
        super(exceptionMsg);
    }

}
