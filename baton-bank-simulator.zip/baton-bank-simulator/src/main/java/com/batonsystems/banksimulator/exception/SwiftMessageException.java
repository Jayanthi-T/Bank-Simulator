package com.batonsystems.banksimulator.exception;

public class SwiftMessageException extends Exception{

	public SwiftMessageException(String exceptionMessage) {
		super(exceptionMessage);
	}
}
