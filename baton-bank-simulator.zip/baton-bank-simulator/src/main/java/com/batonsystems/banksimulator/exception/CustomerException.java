package com.batonsystems.banksimulator.exception;

public class CustomerException extends Exception{
	
	public CustomerException(String exceptionMessage) {
		super(exceptionMessage);
	}

}
